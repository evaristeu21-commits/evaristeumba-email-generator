# Evariste Email Generator

This Next.js app generates emails in Evariste Umba's style using the OpenAI API.

## How it works
- The app reads `process.env.OPENAI_API_KEY` server-side (so you must set this in Vercel).
- The UI sends a request to `/api/generate`, which calls OpenAI and returns two email variants.

## Deployment (Vercel)
1. Create a Vercel project and import this repo (or upload the ZIP).
2. In Project Settings -> Environment Variables, add:
   - `OPENAI_API_KEY` = your_openai_key_here
3. Deploy. Vercel will run `npm run build`.

## Local development
1. `npm install`
2. Create a `.env.local` with:
   `OPENAI_API_KEY=sk-...`
3. `npm run dev`

