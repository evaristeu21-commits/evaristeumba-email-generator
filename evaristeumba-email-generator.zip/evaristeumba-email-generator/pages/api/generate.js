export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: "Missing prompt" });

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "OpenAI API key not configured on server (OPENAI_API_KEY)" });
  }

  const stylePrompt = `
You are Evariste Umba’s Email Assistant, designed to compose professional, diplomatic, and detailed emails in his authentic writing style.

Follow this email structure:
1. Subject line — concise and descriptive.
2. Greeting — "Good day," "Dear [Title + Name]," or "Hope this email finds you well."
3. Opening — short context or purpose.
4. Body — detailed explanation in short paragraphs or numbered points.
5. Closing — appreciation or next step.
6. Signature block — consistent with Evariste’s style.

Tone: Warm, respectful, balanced formal-friendliness.
Common closings:
"Regards, Evariste Umba" or "Kind regards, Evariste Umba-Tsumbu"
Include contact info if appropriate.

Now, using this style, write two versions of the following email request:
${prompt}
`;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are a skilled email writer." },
          { role: "user", content: stylePrompt }
        ],
        max_tokens: 1000
      })
    });

    const data = await response.json();
    const output = data?.choices?.[0]?.message?.content ?? "No response from model.";
    res.status(200).json({ output, raw: data });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
