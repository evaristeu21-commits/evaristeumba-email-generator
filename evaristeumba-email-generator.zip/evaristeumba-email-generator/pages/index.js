import { useState } from "react";

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    setResult("");
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      setResult(data.output || JSON.stringify(data));
    } catch (err) {
      setResult("Error generating email: " + err.message);
    }
    setLoading(false);
  };

  return (
    <div style={{ maxWidth: 800, margin: "2rem auto", fontFamily: "Arial, sans-serif" }}>
      <h1>Evariste Email Generator</h1>
      <p>Generate emails in Evariste Umba’s professional and diplomatic style.</p>

      <label>✉️ Email Request / Topic</label>
      <textarea
        rows="6"
        placeholder="e.g. Write an email to a dean proposing a joint event on justice reform."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        style={{ width: "100%", marginBottom: 12 }}
      />

      <button onClick={handleGenerate} disabled={loading || !prompt}>
        {loading ? "Generating..." : "Generate Email"}
      </button>

      <h3 style={{ marginTop: 24 }}>Generated Email:</h3>
      <pre
        style={{
          whiteSpace: "pre-wrap",
          background: "#f5f5f5",
          padding: 12,
          borderRadius: 8,
        }}
      >
        {result}
      </pre>
    </div>
  );
}
